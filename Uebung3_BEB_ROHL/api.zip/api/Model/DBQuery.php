<?php


interface DBQuery
{
    public function createDBQuery();
}